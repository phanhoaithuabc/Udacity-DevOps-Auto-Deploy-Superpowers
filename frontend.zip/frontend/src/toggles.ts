interface Toggle {
  componentName: string;
  environments: string[];
}

export const toggles: Toggle[] = [];
